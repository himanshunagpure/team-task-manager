import Project from "../models/Project.js";
import crypto from "crypto";
import ProjectInvite from "../models/ProjectInvite.js";

import { sendEmail }
  from "../utils/sendEmail.js";

import {
  OK,
  CREATED,
  BAD_REQUEST,
  NOT_FOUND,
  INTERNAL_SERVER_ERROR,
} from "../utils/statusCode.js";


// ==========================================
// Create Project
// Creator becomes project admin
// ==========================================
export const createProject =
  async (req, res) => {
    try {
      const {
        projectName,
        description,
      } = req.body;

      if (!projectName) {
        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "Project name is required",
        });
      }

      // Check duplicate project name for same user
      const existingProject =
        await Project.findOne({
          projectName,
          createdBy:
            req.user._id,
        });

      if (existingProject) {
        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "You already have a project with this name",
        });
      }

      const project =
        await Project.create({
          projectName,
          description,

          createdBy:
            req.user._id,

          // Creator becomes admin automatically
          members: [
            {
              user:
                req.user._id,

              role:
                "admin",
            },
          ],
        });

      return res.status(
        CREATED
      ).json({
        success: true,
        message:
          "Project created successfully",
        data: project,
      });
    } catch (error) {
      console.error(
        "Create Project Error:",
        error
      );

      return res.status(
        INTERNAL_SERVER_ERROR
      ).json({
        success: false,
        message:
          "Unable to create project",
      });
    }
  };



// ==========================================
// Get My Projects
// User sees only joined projects
// ==========================================
export const getMyProjects =
  async (req, res) => {
    try {
      const projects =
        await Project.find({
          "members.user":
            req.user._id,
        })
          .populate(
            "createdBy",
            "fullName email"
          )
          .populate(
            "members.user",
            "fullName email"
          )
          .sort({
            createdAt:
              -1,
          });

      return res.status(
        OK
      ).json({
        success: true,
        count:
          projects.length,
        data: projects,
      });
    } catch (error) {
      console.error(
        "Get Projects Error:",
        error
      );

      return res.status(
        INTERNAL_SERVER_ERROR
      ).json({
        success: false,
        message:
          "Unable to fetch projects",
      });
    }
  };



// ==========================================
// Get Single Project
// ==========================================
export const getProjectById =
  async (req, res) => {
    try {
      const project =
        await Project.findById(
          req.params.projectId
        )
          .populate(
            "createdBy",
            "fullName email"
          )
          .populate(
            "members.user",
            "fullName email"
          );

      if (!project) {
        return res.status(
          NOT_FOUND
        ).json({
          success: false,
          message:
            "Project not found",
        });
      }

      return res.status(
        OK
      ).json({
        success: true,
        data: project,
      });
    } catch (error) {
      console.error(
        "Get Project Error:",
        error
      );

      return res.status(
        INTERNAL_SERVER_ERROR
      ).json({
        success: false,
        message:
          "Unable to fetch project",
      });
    }
  };


  export const inviteMemberToProject =
  async (req, res) => {
    try {
      const {
        projectId,
      } = req.params;

      const {
        email,
      } = req.body;

      if (!email) {
        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "Member email is required",
        });
      }

      const project =
        await Project.findById(
          projectId
        );

      if (!project) {
        return res.status(
          NOT_FOUND
        ).json({
          success: false,
          message:
            "Project not found",
        });
      }

      // Prevent inviting yourself
      if (
        email.toLowerCase() ===
        req.user.email
      ) {
        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "You are already part of this project",
        });
      }

      // Already invited?
      const existingInvite =
        await ProjectInvite.findOne(
          {
            email:
              email.toLowerCase(),

            project:
              projectId,

            status:
              "pending",
          }
        );

      if (
        existingInvite
      ) {
        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "Invitation already sent to this email",
        });
      }

      // Generate invite token
      const inviteToken =
        crypto.randomBytes(
          32
        ).toString(
          "hex"
        );

      // Create invite
      const invite =
        await ProjectInvite.create(
          {
            email:
              email.toLowerCase(),

            project:
              projectId,

            invitedBy:
              req.user._id,

            token:
              inviteToken,

            expiresAt:
              new Date(
                Date.now() +
                  24 *
                    60 *
                    60 *
                    1000
              ),
          }
        );

      // Invite link
      const inviteLink =
        `${process.env.CLIENT_URL}/invite/${invite.token}`;

      // Send email
      await sendEmail({
        to: email,

        subject:
          "Project Invitation",

        html: `
          <h2>Team Invitation</h2>

          <p>
            You have been invited to join a project.
          </p>

          <a href="${inviteLink}">
            Accept Invitation
          </a>

          <p>
            Link expires in 24 hours.
          </p>
        `,
      });

      return res.status(
        OK
      ).json({
        success: true,
        message:
          "Invitation sent successfully",
      });
    } catch (error) {
      console.error(
        "Invite Error:",
        error
      );

      return res.status(
        INTERNAL_SERVER_ERROR
      ).json({
        success: false,
        message:
          "Unable to send invitation",
      });
    }
  };

  export const acceptProjectInvitation =
  async (req, res) => {
    try {
      const { token } =
        req.params;

      // Find invite by token
      const invite =
        await ProjectInvite.findOne(
          {
            token,
          }
        );

      if (!invite) {
        return res.status(
          NOT_FOUND
        ).json({
          success: false,
          message:
            "Invitation not found",
        });
      }

      // Already accepted
      if (
        invite.status ===
        "accepted"
      ) {
        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "Invitation already accepted",
        });
      }

      // Expired link
      if (
        invite.expiresAt <
        new Date()
      ) {
        invite.status =
          "expired";

        await invite.save();

        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "Invitation link has expired",
        });
      }

      // Security check
      // Invite email must match logged in user
      if (
        invite.email !==
        req.user.email
      ) {
        return res.status(
          FORBIDDEN
        ).json({
          success: false,
          message:
            "This invitation does not belong to your account",
        });
      }

      // Find project
      const project =
        await Project.findById(
          invite.project
        );

      if (!project) {
        return res.status(
          NOT_FOUND
        ).json({
          success: false,
          message:
            "Project not found",
        });
      }

      // Already a member?
      const alreadyMember =
        project.members.find(
          (
            member
          ) =>
            member.user.toString() ===
            req.user._id.toString()
        );

      if (
        alreadyMember
      ) {
        return res.status(
          BAD_REQUEST
        ).json({
          success: false,
          message:
            "You are already a member of this project",
        });
      }

      // Add user as member
      project.members.push(
        {
          user:
            req.user._id,

          role:
            "member",
        }
      );

      await project.save();

      // Mark invite accepted
      invite.status =
        "accepted";

      await invite.save();

      return res.status(
        OK
      ).json({
        success: true,
        message:
          "You joined the project successfully",
      });
    } catch (error) {
      console.error(
        "Accept Invite Error:",
        error
      );

      return res.status(
        INTERNAL_SERVER_ERROR
      ).json({
        success: false,
        message:
          "Unable to accept invitation",
      });
    }
  };
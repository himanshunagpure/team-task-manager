import express from "express";

import {
  createProject,
  getMyProjects,
  inviteMemberToProject,
    acceptProjectInvitation,
} from "../controllers/projectController.js";

import {
  protect,
} from "../middleware/authMiddleware.js";



import {
  checkProjectAdmin,
} from "../middleware/projectRoleMiddleware.js";



const projectRouter =
  express.Router();


// Create project
projectRouter.post(
  "/create",
  protect,
  createProject
);


// Get projects
projectRouter.get(
  "/my-projects",
  protect,
  getMyProjects
);


// Invite member
projectRouter.post(
  "/:projectId/invite",
  protect,
  checkProjectAdmin,
  inviteMemberToProject
);

projectRouter.post(
  "/invite/:token/accept",
  protect,
  acceptProjectInvitation
);

export default projectRouter;
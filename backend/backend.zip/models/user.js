import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const userSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: true,
      trim: true,
    },

    email: {
      type: String,
      unique: true,
      lowercase: true,
      sparse: true,
      required: true,
    },

    role: {
      type: String,
      enum: ["user", "owner", "superadmin"],
      default: "user",
    },

    password: {
      type: String,
      required: true,
      select: false,
    },


    location: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point",
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        default: [0, 0],
      },
      city: {
        type: String,
      },
      address: {
        type: String,
      },
    },

    // ✅ Account Status
    isBlocked: {
      type: Boolean,
      default: false,
    },

    isVerified: {
      type: Boolean,
      default: false,
    },

    // ✅ OTP Fields
    otp: String,
    otpExpire: Date,

    // ✅ Password Reset
    resetPasswordOtp: String,
    resetPasswordExpire: Date,

    // ✅ Rating System
    rating: {
      average: {
        type: Number,
        default: 0,
      },
      totalReviews: {
        type: Number,
        default: 0,
      },
    },

    // ✅ Wallet
    walletBalance: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

// Hash password before saving
userSchema.pre("save", async function () {
  if (!this.isModified("password")) return;
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Compare password method
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// ✅ Geo Index
userSchema.index({ location: "2dsphere" });

// prevent OverwriteModelError in development/hot-reload environments
// if the model already exists, reuse it instead of compiling again.
const User = mongoose.models.User || mongoose.model("User", userSchema);
export default User;